// Build Map
mapboxgl.accessToken =
  "pk.eyJ1Ijoic2FyYXRocyIsImEiOiJja2dxcmpua2owODVrMnFxdzJqazk0Y3FqIn0.3zP_RXiZ4FkwyDNXmlccqw";

// Map
var map = new mapboxgl.Map({
  container: "map", // container id
  style: "mapbox://styles/mapbox/streets-v11", // style URL
  center: [80.27, 13.09], // starting position [lng, lat]
  zoom: 9, // starting zoom
});

// Direction Controls
var directionControls = {
  inputs: true, // Default -> true
  instructions: true, // Default -> true
  profileSwitcher: true, // Default -> true
};

// Direction
var directions = new MapboxDirections({
  accessToken: mapboxgl.accessToken,
  profile: "mapbox/walking",
  steps: "false",
  language: "ar",
  placeholderOrigin: "Choose Starting Point",
  placeholderDestination: "Choose Destination",
  controls: directionControls,
});

// Moveable Marker
var movableMarker = new mapboxgl.Marker({
  draggable: true,
});

movableMarker.setLngLat([80.21838068962099, 13.044492753397355]);

map.on("load", function () {
  map.addControl(directions, "top-left"); // Add Direction Control
  directions.setOrigin([80.21838068962099, 13.044492753397355]); // [lng, lat]
  directions.setDestination([80.22474288940431, 13.041696833111496]); // [lng, lat]
  movableMarker.addTo(map);
});

// loading { type: } Type is one of 'origin' or 'destination'
// profile { profile } Profile is one of 'driving', 'walking', or 'cycling'
// origin { feature } Fired when origin is set
// destination { feature } Fired when destination is set
// route { route } Fired when a route is updated
// error { error } Error as string

//Get origin and destination long lat
directions.on("origin", function (e) {
  console.log(
    "Origin Set on",
    "lon:" +
      e.feature.geometry.coordinates[0] +
      "," +
      "Lat:" +
      "lat:" +
      e.feature.geometry.coordinates[0]
  );
});

directions.on("destination", function (e) {
  console.log(
    "destination Set on",
    "lon:" +
      e.feature.geometry.coordinates[0] +
      "," +
      "Lat:" +
      "lat:" +
      e.feature.geometry.coordinates[0]
  );
});

//Movable Marker Event
movableMarker.on("dragend", function () {
  console.log("Movable marker location " + movableMarker.getLngLat());
});

//Directions -> Reference https://blog.mapbox.com/mapbox-gl-directions-plugin-320694594eae
