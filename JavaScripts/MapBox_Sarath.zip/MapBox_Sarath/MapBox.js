//Build Map
mapboxgl.accessToken = 'pk.eyJ1Ijoic2FyYXRocyIsImEiOiJja2dxcmpua2owODVrMnFxdzJqazk0Y3FqIn0.3zP_RXiZ4FkwyDNXmlccqw';

//Add Map
var map = new mapboxgl.Map({
container: 'map', // container id
style: 'mapbox://styles/mapbox/streets-v11', // style URL
center: [-74.5, 40], // starting position [lng, lat]
zoom: 9 // starting zoom
});

//Directions
var directions = new MapboxDirections({
    accessToken: mapboxgl.accessToken
    });

//Add Direction Control
map.addControl(directions,'top-left');

//Calculate distance between center and marker
var from = turf.point([13.0424332,80.221613]);//cloutics
var to = turf.point([13.0432531,80.2047042]);//sIMS
var options = {units: 'kilometers'};
var distance = turf.distance(from, to, options);
console.log(distance)
